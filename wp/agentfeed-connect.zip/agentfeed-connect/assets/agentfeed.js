// AgentFeed Connect: counts visits and presses, and puts approved changes on the page.
// Ships inside the plugin, so nothing runs here that the site did not install. The approved changes
// come from the site itself (#af-data and #af-patch, written by the plugin from its own database);
// only a logged-in editor of this site (data-editor) may see a change not yet approved, or send the
// studio a drawing of the page. Counts only: no cookie, nothing stored on the visitor's device.
(function () {
  var s = document.currentScript, site = s && (s.getAttribute("data-site") || "").toLowerCase();
  if (!site || !/^[a-z0-9-]{1,60}$/.test(site)) return;
  var api = s.getAttribute("data-api") || "", editor = s.getAttribute("data-editor") === "1";
  if (!/^https:\/\/[a-z0-9.-]+$/.test(api)) return;
  (function () {
    if (!document.querySelectorAll) return;
    var data = null, extra = null, st = null;
    try { data = JSON.parse((document.getElementById("af-data") || {}).textContent || "null"); } catch (x) { data = null; }
    data = data || { text: [], bar: null };
    var q = location.search, pv = editor ? (q.match(/[?&]af-preview=([a-f0-9]{24})/) || [])[1] || "" : "";
    try { if (editor) { if (pv) sessionStorage.setItem("af-pv", pv); else pv = sessionStorage.getItem("af-pv") || ""; } } catch (x) {}
    var snap = editor ? (q.match(/[?&]af-snap=([a-f0-9]{24})/) || [])[1] : "";
    // the tokens leave the address bar once read, so the site's own analytics never record them
    if (/[?&]af-(preview|snap)=/.test(q)) try { history.replaceState(history.state, "", location.href.replace(/([?&])af-(preview|snap)=[a-f0-9]{24}&?/g, "$1").replace(/[?&]$/, "")); } catch (x) {}
    // the same rule as BAD_CSS in patches.mjs and core.php: a preview is held to it here too
    var BAD = /<|\\|\/\*|\/\/|url\s*\(|image-set|src\s*\(|@import|@font-face|expression\s*\(|javascript:|behavio(u)?r\s*:|-moz-binding|@charset/i;
    function apply() {
      if (extra) {
        if (!st || !st.isConnected) { st = st || document.createElement("style"); st.id = "af-preview"; (document.head || document.documentElement).appendChild(st); }
        var hide = (extra.hide || []).filter(function (x) { return !/[<>{}\\;@]|\/\*|\*\//.test(x) && !BAD.test(x); });
        var css = (BAD.test(extra.css || "") ? "" : (extra.css || "")) + hide.map(function (x) { return "\n" + x + "{display:none!important}"; }).join("");
        if (st.textContent !== css) st.textContent = css;
      }
      bar(extra && extra.bar ? extra.bar : data.bar);
      (data.text || []).concat(extra ? extra.text || [] : []).forEach(function (t) {
        // text goes into what a visitor reads, never into an element whose text is code or data
        try { var els = document.querySelectorAll(t.selector); for (var i = 0; i < els.length; i++) {
          var el = els[i];
          if (/^(SCRIPT|STYLE|TITLE|NOSCRIPT|TEMPLATE|TEXTAREA|IFRAME|OBJECT|HEAD|META|LINK|svg|SVG)$/.test(el.tagName) || el.closest("svg,head,#af-bar")) continue;
          if (!el.children.length && el.textContent !== t.text) el.textContent = t.text;
        } } catch (x) {}
      });
    }
    // a line across the top (a sale, holiday hours): set as text, closable for this visit
    function bar(b) {
      var el = document.getElementById('af-bar'), HEX = /^#(?:[0-9a-f]{3}){1,2}$/i, shut = '';
      try { shut = sessionStorage.getItem('af-bar-x') || ''; } catch (x) {}
      if (!b || !b.text || shut === b.text || !document.body) { if (el && (!b || shut === b.text)) el.parentNode.removeChild(el); return; }
      if (el && el.isConnected && el.getAttribute('data-t') === b.text) return;
      if (el && el.parentNode) el.parentNode.removeChild(el);
      el = document.createElement('div'); el.id = 'af-bar'; el.setAttribute('data-t', b.text); el.setAttribute('role', 'status');
      el.setAttribute('style', 'position:relative;z-index:2147483646;text-align:center;padding:9px 44px;font:600 15px/1.4 system-ui,sans-serif;direction:rtl;background:' +
        (HEX.test(b.bg) ? b.bg : '#14171f') + ';color:' + (HEX.test(b.fg) ? b.fg : '#fff'));
      var t = document.createElement('span'); t.textContent = b.text; el.appendChild(t);
      var x = document.createElement('button'); x.type = 'button'; x.textContent = '×'; x.setAttribute('aria-label', 'סגירה');
      x.setAttribute('style', 'position:absolute;left:10px;top:50%;transform:translateY(-50%);background:none;border:0;color:inherit;font:20px system-ui;cursor:pointer');
      x.onclick = function () { try { sessionStorage.setItem('af-bar-x', b.text); } catch (e) {} if (el.parentNode) el.parentNode.removeChild(el); };
      el.appendChild(x); document.body.insertBefore(el, document.body.firstChild);
    }
    function watch() {
      apply(); if (!document.body) document.addEventListener("DOMContentLoaded", apply);
      // pages that draw themselves keep redrawing: the change is put back after each redraw (at most every 150ms)
      if (window.MutationObserver && ((data.text || []).length || data.bar || extra)) { var t = 0; new MutationObserver(function () { if (!t) t = setTimeout(function () { t = 0; apply(); }, 150); }).observe(document.documentElement, { childList: true, subtree: true }); }
    }
    if (pv && window.fetch) fetch(api + "/api/panel?op=patches&site=" + site + "&preview=" + pv).then(function (r) { return r.json(); }).then(function (d) {
      if (d && d.preview) extra = d; else { pv = ""; try { sessionStorage.removeItem("af-pv"); } catch (x) {} }
      watch();
    }).catch(watch); else watch();
    function banner() {
      var b = document.createElement('div');
      b.setAttribute('style', 'position:fixed;bottom:12px;left:12px;z-index:2147483647;background:#14171f;color:#fff;font:14px system-ui;padding:8px 12px;border-radius:10px;direction:rtl');
      b.textContent = 'תצוגה מקדימה של שינוי. רק מי שפתח את הקישור רואה אותה. ';
      var x = document.createElement('a'); x.textContent = 'לצאת'; x.href = location.pathname; x.setAttribute('style', 'color:#9ad');
      x.onclick = function () { try { sessionStorage.removeItem('af-pv'); } catch (e) {} };
      b.appendChild(x); document.body.appendChild(b);
    }
    if (pv) { if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', banner); else banner(); }
    // the drawn page, once, when the studio asked for it (a site that draws itself in the browser)
    if (snap) setTimeout(function () {
      // what a visitor sees: without the logged-in builder's own bar, forms' values or scripts
      var c = document.body ? document.body.cloneNode(true) : null, h = '';
      if (c) { var drop = c.querySelectorAll('#wpadminbar,script,noscript,iframe,input,textarea'); for (var i = 0; i < drop.length; i++) drop[i].parentNode.removeChild(drop[i]); h = c.outerHTML; }
      fetch(api + '/api/panel?op=patch-snap&site=' + site, { method: 'POST', headers: { 'content-type': 'text/plain' }, body: JSON.stringify({ token: snap, html: h.slice(0, 150000) }) }).catch(function () {});
    }, 2500);
  })();
  // a page shown inside another (the desk's before/after) is not a visit
  if (navigator.webdriver || window.top !== window.self) return;
  var CARD = '[itemtype*="Product"],li.product,.product,.product-card,.product-item,.grid-product,.card-wrapper,.wc-block-grid__product,[data-product-id]';
  function isProduct() {
    var og = document.querySelector('meta[property="og:type"]');
    if (og && /product/i.test(og.content)) return true;
    var ld = document.querySelectorAll('script[type="application/ld+json"]');
    for (var i = 0; i < ld.length; i++) if (/"@type"\s*:\s*"Product"/.test(ld[i].textContent)) return true;
    return false;
  }
  function name() {
    var og = document.querySelector('meta[property="og:title"]');
    return ((og && og.content) || document.title || '').split(/ [|\-–·] /)[0].trim();
  }
  function item(el) {
    var c = el && el.closest && el.closest(CARD);
    if (c) {
      var h = c.querySelector('[itemprop="name"],.woocommerce-loop-product__title,.product-title,.card__heading,h1,h2,h3,h4');
      if (h && h.textContent.trim()) return h.textContent.trim();
    }
    return isProduct() ? name() : '';
  }
  function send(e, it, from) {
    var ref = from || '';
    if (!ref) { try { ref = document.referrer ? new URL(document.referrer).hostname : ''; } catch (x) {} }
    if (ref && ref === location.hostname) ref = 'internal';
    var page = location.pathname === '/' ? '/' : (name() || location.pathname);
    var u = api + '/t?s=' + encodeURIComponent(site) + '&e=' + e + '&f=' + encodeURIComponent(ref) +
      '&p=' + encodeURIComponent(page.slice(0, 80)) + '&m=' + (matchMedia('(max-width: 760px)').matches ? 1 : 0) +
      (it ? '&i=' + encodeURIComponent(it.slice(0, 80)) : '');
    try { if (navigator.sendBeacon) navigator.sendBeacon(u); else fetch(u, { mode: 'no-cors', keepalive: true }); } catch (x) {}
  }
  send('view');
  // sites that change page without reloading still count each page once
  var path = location.pathname, push = history.pushState;
  function moved() { if (location.pathname !== path) { path = location.pathname; setTimeout(function () { send('view', '', 'internal'); }, 300); } }
  history.pushState = function () { var r = push.apply(this, arguments); moved(); return r; };
  addEventListener('popstate', moved);
  document.addEventListener('click', function (ev) {
    var a = ev.target.closest && ev.target.closest('a,button'); if (!a) return;
    var h = a.getAttribute('href') || '', cls = String(a.className || '');
    if (/wa\.me|whatsapp/i.test(h)) send('wa', item(a));
    else if (/^tel:/i.test(h)) send('call', item(a));
    else if (/^mailto:/i.test(h)) send('email', item(a));
    else if (/add-to-cart|add_to_cart|\/cart\/add/i.test(h) || /add[-_ ]?to[-_ ]?cart|single_add_to_cart|product-form__submit/i.test(cls) || a.name === 'add') send('cart', item(a));
  }, true);
  // a contact form sent: one that asks for a phone, an e-mail or a message
  document.addEventListener('submit', function (ev) {
    var f = ev.target;
    if (!f || /\/cart\/add|search/i.test((f.action || '') + ' ' + (f.getAttribute('role') || ''))) return;
    if (f.querySelector('input[type=email],input[type=tel],textarea')) send('lead');
  }, true);
})();
