// AgentFeed Connect — the "write to us" window. Step 13 of agentfeed/AGENCY-PRODUCT.md.
//
// Ships inside the plugin and runs only where the site switched it on (the plugin's own setting). A
// visitor writes; the answer comes from what the site itself says, or the business answers in person.
// Nothing from the server is ever put on the page as HTML: every line is text. A phone number is sent
// only with the visitor's own tick, and the thread's key lives in this tab's session storage only.
(function () {
  var s = document.currentScript, site = s && (s.getAttribute("data-site") || "").toLowerCase();
  if (!site || !/^[a-z0-9-]{1,60}$/.test(site) || !document.querySelector) return;
  var api = s.getAttribute("data-api") || "";
  if (!/^https:\/\/[a-z0-9.-]+$/.test(api)) return;
  var title = (s.getAttribute("data-title") || "יש לך שאלה? כתבו לנו").slice(0, 60);
  var base = api + "/api/panel?site=" + encodeURIComponent(site) + "&op=";
  var KEY = "af-inbox-" + site, state = null, poll = null, busy = false, thread = [], notice = "", given = false;
  try { state = JSON.parse(sessionStorage.getItem(KEY) || "null"); } catch (x) { state = null; }
  function keep() { try { sessionStorage.setItem(KEY, JSON.stringify(state)); } catch (x) {} }

  var css = ".afi-b{position:fixed;inset-inline-start:16px;bottom:16px;z-index:2147483000;font:inherit;font-size:15px;border:0;border-radius:999px;" +
    "padding:12px 18px;background:var(--afi-accent,#1f4e5f);color:#fff;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.18)}" +
    ".afi-b:focus-visible,.afi-p button:focus-visible,.afi-p textarea:focus-visible,.afi-p input:focus-visible{outline:3px solid #f2b705;outline-offset:2px}" +
    ".afi-p{position:fixed;inset-inline-start:16px;bottom:76px;z-index:2147483001;width:min(360px,calc(100vw - 32px));max-height:min(560px,calc(100vh - 100px));" +
    "display:flex;flex-direction:column;background:#fff;color:#1d1d1d;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.22);font:inherit;font-size:15px;direction:rtl;overflow:hidden}" +
    ".afi-p[hidden]{display:none}.afi-h{display:flex;justify-content:space-between;align-items:center;padding:12px 14px;background:var(--afi-accent,#1f4e5f);color:#fff}" +
    ".afi-h h2{margin:0;font-size:16px;font-weight:600;color:inherit}.afi-x{background:none;border:0;color:inherit;font-size:22px;line-height:1;cursor:pointer;padding:4px 8px}" +
    ".afi-l{flex:1;overflow-y:auto;padding:12px 14px;display:flex;flex-direction:column;gap:8px}" +
    ".afi-m{max-width:85%;padding:8px 11px;border-radius:12px;white-space:pre-wrap;word-break:break-word;line-height:1.45}" +
    ".afi-v{align-self:flex-start;background:#e8f0f2}.afi-a{align-self:flex-end;background:#f3f3f1}.afi-o{align-self:flex-end;background:#fff4d6}" +
    ".afi-who{display:block;font-size:12px;color:#555;margin-bottom:2px}" +
    ".afi-f{border-top:1px solid #e3e3e3;padding:10px 14px;display:flex;flex-direction:column;gap:8px}" +
    ".afi-f textarea{width:100%;box-sizing:border-box;min-height:64px;resize:vertical;font:inherit;padding:8px;border:1px solid #bbb;border-radius:8px}" +
    ".afi-c{display:flex;gap:6px;align-items:flex-start;font-size:13px;color:#333}.afi-c input{margin-top:3px}" +
    ".afi-f input[type=tel]{font:inherit;padding:7px 8px;border:1px solid #bbb;border-radius:8px;direction:ltr;text-align:right}" +
    ".afi-s{align-self:flex-start;border:0;border-radius:8px;padding:9px 16px;background:var(--afi-accent,#1f4e5f);color:#fff;font:inherit;cursor:pointer}" +
    ".afi-card{display:flex;flex-direction:column;gap:2px;margin-top:8px;padding:8px 10px;border:1px solid #d9e1df;border-radius:10px;background:#fff}" +
    ".afi-card b{font-weight:600}.afi-price{color:#1f4e5f;font-weight:600}.afi-go{color:#1f4e5f;font-size:14px}" +
    ".afi-c.afi-ask{background:#fff4d6;border-radius:8px;padding:6px 8px;font-weight:600}" +
    ".afi-s[disabled]{opacity:.6;cursor:wait}.afi-n{font-size:12px;color:#555;margin:0}.afi-e{color:#a3201a;font-size:13px;margin:0}" +
    "@media (prefers-reduced-motion:no-preference){.afi-p{transition:opacity .15s}}";
  var st = document.createElement("style"); st.id = "afi-style"; st.textContent = css; (document.head || document.documentElement).appendChild(st);

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }
  var btn = el("button", "afi-b", title); btn.type = "button"; btn.setAttribute("aria-expanded", "false"); btn.setAttribute("aria-controls", "afi-panel");
  var panel = el("section", "afi-p"); panel.id = "afi-panel"; panel.hidden = true; panel.setAttribute("role", "dialog"); panel.setAttribute("aria-labelledby", "afi-title");
  var head = el("div", "afi-h"), h2 = el("h2", "", title), x = el("button", "afi-x", "×");
  h2.id = "afi-title"; x.type = "button"; x.setAttribute("aria-label", "סגירה");
  head.appendChild(h2); head.appendChild(x);
  var list = el("div", "afi-l"); list.setAttribute("role", "log"); list.setAttribute("aria-label", "השיחה");
  var say = el("p", ""); say.setAttribute("aria-live", "polite"); say.style.cssText = "position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)";
  var form = el("form", "afi-f"), ta = el("textarea"), lab = el("label", "afi-c"), cb = el("input"), tel = el("input"),
      send = el("button", "afi-s", "שליחה"), note = el("p", "afi-n", "התשובות מבוססות על מה שכתוב באתר. מה שלא כתוב בו — בעל העסק עונה בעצמו."), err = el("p", "afi-e");
  ta.setAttribute("aria-label", "ההודעה שלך"); ta.placeholder = "מה תרצו לשאול?"; ta.maxLength = 1000; ta.required = true;
  cb.type = "checkbox"; cb.id = "afi-ok"; lab.appendChild(cb); lab.appendChild(document.createTextNode("מותר לחזור אליי בטלפון")); lab.setAttribute("for", "afi-ok");
  tel.type = "tel"; tel.placeholder = "מספר טלפון"; tel.setAttribute("aria-label", "מספר טלפון"); tel.hidden = true; tel.autocomplete = "tel"; tel.maxLength = 20;
  send.type = "submit"; err.setAttribute("role", "alert");
  form.appendChild(ta); form.appendChild(lab); form.appendChild(tel); form.appendChild(send); form.appendChild(note); form.appendChild(err);
  panel.appendChild(head); panel.appendChild(list); panel.appendChild(form); panel.appendChild(say);
  document.body.appendChild(panel); document.body.appendChild(btn);

  var WHO = { visitor: "", assistant: "תשובה מהאתר", owner: "בעל העסק" };
  function line(m) {
    var b = el("div", "afi-m " + (m.who === "visitor" ? "afi-v" : m.who === "owner" ? "afi-o" : "afi-a"));
    if (WHO[m.who]) b.appendChild(el("span", "afi-who", WHO[m.who]));
    b.appendChild(document.createTextNode(String(m.text || "")));
    // product cards: a name, a price, and the product's own page — built from the shop's price list on the
    // server, never from the model's words. Only an https page becomes a link.
    (m.cards || []).slice(0, 3).forEach(function (c) {
      var card = el("div", "afi-card"), nm = el("b", "", String(c.name || ""));
      card.appendChild(nm);
      card.appendChild(el("span", "afi-price", c.price === null || c.price === undefined ? "המחיר לא מפורסם באתר" : Number(c.price).toLocaleString("he-IL") + " ₪"));
      if (/^https:\/\//.test(String(c.url || ""))) { var a = el("a", "afi-go", "לפרטים ←"); a.href = c.url; a.target = "_blank"; a.rel = "noopener"; card.appendChild(a); }
      b.appendChild(card);
    });
    list.appendChild(b);
  }
  // The thread as the server keeps it, and after it — only while the business has not answered yet —
  // the line that says the message arrived. Only what is new is read out to a screen reader.
  function render(fresh) {
    while (list.firstChild) list.removeChild(list.firstChild);
    for (var i = 0; i < thread.length; i++) line(thread[i]);
    var last = thread[thread.length - 1];
    if (notice && last && last.who === "visitor") line({ who: "assistant", text: notice });
    list.scrollTop = list.scrollHeight;
    if (fresh && list.lastChild) {
      var last2 = thread[thread.length - 1], shown = notice && last2 && last2.who === "visitor" ? { who: "assistant", text: notice } : last2;
      if (shown && shown.who !== "visitor") say.textContent = (WHO[shown.who] ? WHO[shown.who] + ": " : "") + shown.text;
    }
  }
  function call(op, body, done) {
    var r = new XMLHttpRequest();
    r.open(body ? "POST" : "GET", base + op + (body ? "" : "&id=" + encodeURIComponent(state.id) + "&vkey=" + encodeURIComponent(state.vkey)));
    r.setRequestHeader("content-type", "application/json");
    r.timeout = 60000;
    r.onload = function () { var j = null; try { j = JSON.parse(r.responseText); } catch (e) {} done(r.status, j); };
    r.onerror = r.ontimeout = function () { done(0, null); };
    r.send(body ? JSON.stringify(body) : null);
  }
  function refresh() {
    if (state && state.id) call("inbox-thread", null, function (code, j) {
      if (code !== 200 || !j || !j.thread) return;
      if (j.contact && !given) { given = true; lab.hidden = true; tel.hidden = true; }
      if (j.thread.length !== thread.length) { thread = j.thread; render(true); }
    });
  }
  function open() {
    panel.hidden = false; btn.setAttribute("aria-expanded", "true"); ta.focus(); refresh();
    if (!poll) poll = setInterval(function () { if (!document.hidden) refresh(); }, 15000);
  }
  function close() { panel.hidden = true; btn.setAttribute("aria-expanded", "false"); clearInterval(poll); poll = null; btn.focus(); }
  btn.addEventListener("click", function () { panel.hidden ? open() : close(); });
  x.addEventListener("click", close);
  panel.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
  cb.addEventListener("change", function () { tel.hidden = !cb.checked; if (cb.checked) tel.focus(); });
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var text = ta.value.replace(/^\s+|\s+$/g, "");
    if (!text || busy) return;
    busy = true; send.disabled = true; err.textContent = "";
    var body = state && state.id ? { id: state.id, vkey: state.vkey, text: text }
      : { text: text, page: location.pathname.slice(0, 120) };
    if (cb.checked && !given) { body.consent = true; body.phone = tel.value; }
    thread = thread.concat([{ who: "visitor", text: text }]); render(false);
    call("inbox-write", body, function (code, j) {
      busy = false; send.disabled = false;
      if (code === 200 && j) {
        if (j.vkey) { state = { id: j.id, vkey: j.vkey }; keep(); }
        notice = j.state === "drafted" || j.state === "handed" ? String(j.reply || "") : "";
        if (body.consent) { given = true; lab.hidden = true; tel.hidden = true; }
        // the shop would like to call back: the permission box is offered, never ticked for them
        if (j.ask_contact && !given) { lab.classList.add("afi-ask"); lab.lastChild.textContent = "רוצים שנחזור אליכם? סמנו כאן והשאירו מספר"; }
        ta.value = ""; render(true); refresh();
      } else {
        err.textContent = code === 429 ? "נשלחו הרבה הודעות בזמן קצר. אפשר לנסות שוב בעוד כמה דקות."
          : code === 0 ? "אין חיבור כרגע. ההודעה לא נשלחה — אפשר לנסות שוב." : "ההודעה לא נשלחה. אפשר לנסות שוב.";
        thread = thread.slice(0, -1); render(false);
      }
    });
  });
})();
