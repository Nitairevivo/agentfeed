<?php
/**
 * The judgement, without WordPress: who may sign, what a signed order may do, and what a change may hold.
 *
 * Everything the AgentFeed server sends is checked here as if the server were hostile. The server
 * carries signed statements; it cannot make one. A statement counts only when a device this site
 * pinned (or one a pinned team device vouched for) signed it, for this site, in time, once, and
 * within the bounds below. The same rules are written in server/lib/sign.mjs and patches.mjs, and
 * where the two could ever differ, this file is the one that decides.
 */

if (!defined('ABSPATH') && !defined('AGENTFEED_TEST')) exit;

const AGENTFEED_MAX_LIFE = 604800;   // seven days: an order not delivered by then is not delivered at all
const AGENTFEED_SKEW = 600;          // ten minutes of clock difference
const AGENTFEED_KINDS = array('wp', 'wp-undo', 'patch', 'patch-undo');

function agentfeed_b64u_dec($s) {
	$s = (string) $s;
	if (!preg_match('/^[A-Za-z0-9_-]+$/', $s)) return '';
	try { return sodium_base642bin($s, SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING); } catch (Throwable $e) { return ''; }
}
function agentfeed_b64u_enc($bin) { return sodium_bin2base64($bin, SODIUM_BASE64_VARIANT_URLSAFE_NO_PADDING); }

/** A key's id: the first 16 hex of SHA-256 over its 32 raw bytes. Also what people compare by eye. */
function agentfeed_kid($pub) {
	if (!preg_match('/^[A-Za-z0-9_-]{43}$/', (string) $pub)) return '';
	$raw = agentfeed_b64u_dec($pub);
	return strlen($raw) === 32 ? substr(hash('sha256', $raw), 0, 16) : '';
}
function agentfeed_fingerprint($kid) { return trim(chunk_split(strtoupper((string) $kid), 4, ' ')); }

function agentfeed_verify($pub, $msg, $sig) {
	if (!preg_match('/^[A-Za-z0-9_-]{43}$/', (string) $pub) || !preg_match('/^[A-Za-z0-9_-]{86}$/', (string) $sig)) return false;
	$p = agentfeed_b64u_dec($pub); $s = agentfeed_b64u_dec($sig);
	if (strlen($p) !== 32 || strlen($s) !== 64) return false;
	try { return sodium_crypto_sign_verify_detached($s, (string) $msg, $p); } catch (Throwable $e) { return false; }
}

function agentfeed_scope_ok($scope) { return (bool) preg_match('/^(team|client:[a-z0-9-]{1,60}:(design|store|both|all))$/', (string) $scope); }
function agentfeed_line($s, $n) { return mb_substr(preg_replace('/[\r\n]+/', ' ', (string) $s), 0, $n); }
function agentfeed_key_msg($agency, $k) {
	return implode("\n", array('AF-KEY-1', $agency, $k['kid'], $k['pub'], $k['scope'], agentfeed_line($k['name'] ?? '', 60), $k['at'] ?? ''));
}
function agentfeed_revoke_msg($agency, $kid, $at) { return implode("\n", array('AF-REVOKE-1', $agency, $kid, $at)); }

/**
 * Which devices this site trusts, from the ones it already trusts, by signatures only: a device joins
 * when a trusted team device vouched for it, and leaves for good when a trusted team device removed it.
 * Returns array(trusted by kid, removed kids).
 */
function agentfeed_trust_walk($agency, array $trusted, array $keys, array $revokes, array $gone) {
	$out = array_fill_keys($gone, true);
	foreach ($trusted as $kid => $k) if (isset($out[$kid])) unset($trusted[$kid]);
	do {
		$changed = false;
		foreach ($revokes as $r) {
			if (!is_array($r) || empty($r['kid']) || isset($out[$r['kid']])) continue;
			$by = $trusted[$r['by'] ?? ''] ?? null;
			if ($by && $by['scope'] === 'team' && agentfeed_verify($by['pub'], agentfeed_revoke_msg($agency, $r['kid'], $r['at'] ?? ''), $r['sig'] ?? '')) {
				$out[$r['kid']] = true; unset($trusted[$r['kid']]); $changed = true;
			}
		}
		foreach ($keys as $k) {
			if (!is_array($k) || empty($k['kid']) || isset($trusted[$k['kid']]) || isset($out[$k['kid']]) || empty($k['end']['by'])) continue;
			if (agentfeed_kid($k['pub'] ?? '') !== $k['kid'] || !agentfeed_scope_ok($k['scope'] ?? '')) continue;
			$by = $trusted[$k['end']['by']] ?? null;
			if ($by && $by['scope'] === 'team' && agentfeed_verify($by['pub'], agentfeed_key_msg($agency, $k), $k['end']['sig'] ?? '')) {
				$trusted[$k['kid']] = array('kid' => $k['kid'], 'pub' => $k['pub'], 'scope' => $k['scope'], 'name' => agentfeed_line($k['name'] ?? '', 60), 'at' => (string) ($k['at'] ?? ''), 'by' => $k['end']['by']);
				$changed = true;
			}
		}
	} while ($changed);
	return array($trusted, array_keys($out));
}

/** The devices a site pins when it connects: the studio's roots as shown to the owner, then whoever they vouched for. */
function agentfeed_first_trust($agency, array $keys, array $revokes) {
	$roots = array();
	foreach ($keys as $k) {
		if (empty($k['root']) || ($k['scope'] ?? '') !== 'team' || agentfeed_kid($k['pub'] ?? '') !== ($k['kid'] ?? '')) continue;
		$roots[$k['kid']] = array('kid' => $k['kid'], 'pub' => $k['pub'], 'scope' => 'team', 'name' => agentfeed_line($k['name'] ?? '', 60), 'at' => (string) ($k['at'] ?? ''), 'by' => '');
	}
	return agentfeed_trust_walk($agency, $roots, $keys, $revokes, array());
}

/** May this device sign this kind of change on this site? */
function agentfeed_allows($scope, $site, $kind) {
	if ($scope === 'team') return true;
	if (!preg_match('/^client:([a-z0-9-]{1,60}):(design|store|both|all)$/', (string) $scope, $m) || $m[1] !== $site) return false;
	$want = strpos($kind, 'wp') === 0 ? 'store' : 'design';
	return $m[2] === 'all' || $m[2] === 'both' || $m[2] === $want;
}

/**
 * A signed order, judged: returns array('order' => ..., 'key' => ...) or array('error' => ...).
 * $ctx: agency, site, trusted (by kid), seen (order id => time), now (unix seconds).
 */
function agentfeed_check_order($item, array $ctx) {
	$k = $ctx['trusted'][(string) ($item['kid'] ?? '')] ?? null;
	if (!$k) return array('error' => 'signed by a device this site does not trust');
	$msg = (string) ($item['msg'] ?? '');
	if (strlen($msg) > 60000 || !agentfeed_verify($k['pub'], $msg, $item['sig'] ?? '')) return array('error' => 'the signature does not match');
	$o = json_decode($msg, true);
	if (!is_array($o) || ($o['v'] ?? 0) !== 1 || ($o['agency'] ?? '') !== $ctx['agency'] || ($o['site'] ?? '') !== $ctx['site']) return array('error' => 'an order for another site');
	if (!preg_match('/^[a-f0-9]{24}$/', (string) ($o['id'] ?? '')) || !in_array($o['kind'] ?? '', AGENTFEED_KINDS, true) || !is_array($o['body'] ?? null)) return array('error' => 'not an order');
	if (isset($ctx['seen'][$o['id']])) return array('error' => 'already done', 'seen' => true);
	$t = (int) $ctx['now'];
	if (!is_int($o['iat'] ?? null) || !is_int($o['exp'] ?? null) || $o['iat'] > $t + AGENTFEED_SKEW || $o['exp'] < $t || $o['exp'] - $o['iat'] > AGENTFEED_MAX_LIFE) return array('error' => 'the order is out of its time');
	if (!agentfeed_allows($k['scope'], $ctx['site'], $o['kind'])) return array('error' => 'this device may not sign this kind of change here');
	return array('order' => $o, 'key' => $k);
}

// ── what a product change may hold: judged against the store as it is now, not as the server says ──

/**
 * $current: product id => array(regular_price, sale_price, stock_status, name, simple: bool).
 * Returns the changes that pass, each array(id, field, value). Anything else is dropped, not trimmed.
 */
function agentfeed_clean_changes($raw, array $current) {
	$fields = array('regular_price', 'sale_price', 'stock_status', 'name');
	$now = $current; $out = array(); $seen = array();
	foreach (array_slice(is_array($raw) ? $raw : array(), 0, 30) as $c) {
		$id = (int) ($c['id'] ?? 0); $field = (string) ($c['field'] ?? '');
		if (!isset($now[$id]) || !in_array($field, $fields, true) || isset($seen["$id|$field"])) continue;
		$seen["$id|$field"] = true;
		$p = $now[$id]; $value = trim((string) ($c['value'] ?? ''));
		$price = '/^\d{1,7}(\.\d{1,2})?$/';
		if (($field === 'regular_price' || $field === 'sale_price') && empty($p['simple'])) continue;
		if ($field === 'regular_price') {
			// at most to half or to double in one change; a price with nothing to compare to is not ours to set
			$old = (float) $p['regular_price'];
			if (!preg_match($price, $value) || (float) $value <= 0 || $old <= 0 || (float) $value < $old / 2 || (float) $value > $old * 2) continue;
		}
		if ($field === 'sale_price' && $value !== '') {
			// a sale takes at most 60% off, and is below the price
			$reg = (float) $p['regular_price'];
			if (!preg_match($price, $value) || (float) $value <= 0 || ($reg > 0 && ((float) $value >= $reg || (float) $value < 0.4 * $reg))) continue;
		}
		if ($field === 'stock_status' && !in_array($value, array('instock', 'outofstock', 'onbackorder'), true)) continue;
		if ($field === 'name') {
			$value = mb_substr(str_replace(array('<', '>'), '', $value), 0, 120);
			if ($value === '' || preg_match('~https?:|www\.|\.(com|co\.il|net|org|io)\b~i', $value)) continue;
		}
		if ((string) ($p[$field] ?? '') === $value) continue;
		$out[] = array('id' => $id, 'field' => $field, 'value' => $value);
		$now[$id][$field] = $value;
	}
	return $out;
}

// ── what a design patch may hold: CSS that loads and runs nothing, text set as text ──

const AGENTFEED_BAD_CSS = '~<|\\\\|/\*|//|url\s*\(|image-set|src\s*\(|@import|@font-face|expression\s*\(|javascript:|behavio(u)?r\s*:|-moz-binding|@charset~i';
const AGENTFEED_BAD_SEL = '~^(\s*(html|body|\*|:root|head)\s*)$|^\s*(html|body)\s*[>*\s]\s*\*?\s*$|(^|,)\s*(html|body|\*)\s*(,|$)|[<>{}\\\\]|\bscript\b|\bstyle\b~i';
const AGENTFEED_BAD_SEL_CSS = '~[;@]|/\*|\*/|af-|\[\s*type\b|(^|[\s>+~,(])(title|noscript|template|textarea|meta|link|head|svg)(?![-\w])~i';
const AGENTFEED_ADDRESS = '~https?:|www\s*[.．。]|[a-z0-9-]+\s*(\.|．|。|\[\s*dot\s*\]|\(\s*dot\s*\)|\s+dot\s+|\s+נקודה\s+)\s*[a-z]{2,}\b~iu';

function agentfeed_clean_css($css) {
	$c = trim(mb_substr((string) $css, 0, 20000));
	if ($c === '') return '';
	if (preg_match(AGENTFEED_BAD_CSS, $c)) return null;
	$depth = 0;
	foreach (str_split($c) as $ch) { if ($ch === '{') $depth++; if ($ch === '}') $depth--; if ($depth < 0) return null; }
	return $depth === 0 ? $c : null;
}
function agentfeed_clean_selector($s) {
	$v = trim(mb_substr((string) $s, 0, 200));
	return $v !== '' && !preg_match(AGENTFEED_BAD_SEL, $v) && !preg_match(AGENTFEED_BAD_SEL_CSS, $v) && !preg_match(AGENTFEED_BAD_CSS, $v) ? $v : null;
}
/** A patch as the site keeps it, or null: anything outside the limits refuses the whole patch. */
function agentfeed_clean_patch($p) {
	if (!is_array($p)) return null;
	$css = agentfeed_clean_css($p['css'] ?? '');
	if ($css === null) return null;
	$text = array();
	foreach (array_slice(is_array($p['text'] ?? null) ? $p['text'] : array(), 0, 30) as $t) {
		$sel = agentfeed_clean_selector($t['selector'] ?? ''); $val = trim(mb_substr((string) ($t['text'] ?? ''), 0, 500));
		if ($sel === null || $val === '' || preg_match(AGENTFEED_ADDRESS, $val)) return null;
		$text[] = array('selector' => $sel, 'text' => $val);
	}
	$hide = array();
	foreach (array_slice(is_array($p['hide'] ?? null) ? $p['hide'] : array(), 0, 20) as $h) {
		$sel = agentfeed_clean_selector($h);
		if ($sel === null) return null;
		$hide[] = $sel;
	}
	$bar = null;
	if (is_array($p['bar'] ?? null)) {
		$bt = trim(preg_replace('/\s+/u', ' ', mb_substr((string) ($p['bar']['text'] ?? ''), 0, 140)));
		if ($bt === '' || preg_match(AGENTFEED_ADDRESS, $bt)) return null;
		$hex = '/^#(?:[0-9a-f]{3}){1,2}$/i';
		$bar = array('text' => $bt, 'bg' => preg_match($hex, (string) ($p['bar']['bg'] ?? '')) ? $p['bar']['bg'] : '#14171f',
		             'fg' => preg_match($hex, (string) ($p['bar']['fg'] ?? '')) ? $p['bar']['fg'] : '#ffffff');
	}
	if ($css === '' && !$text && !$hide && !$bar) return null;
	return array('css' => $css, 'text' => $text, 'hide' => $hide, 'bar' => $bar);
}

/** Everything the page gets from the kept patches, in the order they were approved. */
function agentfeed_page_patch(array $patches) {
	$css = ''; $text = array(); $bar = null;
	foreach ($patches as $p) {
		$c = agentfeed_clean_patch($p);   // judged again on the way out: what was kept is not trusted either
		if (!$c) continue;
		if ($c['css'] !== '') $css .= "\n" . $c['css'];
		foreach ($c['hide'] as $h) $css .= "\n" . $h . '{display:none!important}';
		$text = array_merge($text, $c['text']);
		if ($c['bar']) $bar = $c['bar'];
	}
	return array('css' => $css, 'text' => $text, 'bar' => $bar);
}
