<?php
// Removing the plugin removes everything it kept: the connection, the site's key, the devices, the log,
// and the approved design changes. The products keep whatever values they have.
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
foreach (array('agentfeed_conn', 'agentfeed_sk', 'agentfeed_trust', 'agentfeed_after', 'agentfeed_seen', 'agentfeed_undo',
               'agentfeed_patches', 'agentfeed_log', 'agentfeed_site', 'agentfeed_direct') as $o) delete_option($o);
wp_clear_scheduled_hook('agentfeed_pull');
