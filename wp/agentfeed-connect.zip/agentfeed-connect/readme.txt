=== AgentFeed Connect ===
Requires at least: 5.6
Requires PHP: 7.4
Stable tag: 2.1.0
License: GPLv2 or later

Connects the site to its studio's system: visit counts for the owner's panel,
and changes the studio approved and signed. AgentFeed holds no password to the
site, and the site carries out nothing that was not signed.

== What it does ==
* Counts visits and presses (WhatsApp, call, e-mail, cart) with a script that
  ships inside the plugin (assets/agentfeed.js). No cookie, nothing kept on the
  visitor's device, nothing loaded from another address.
* Carries out a change only when one of the studio's signing devices signed it
  (Ed25519, checked here with PHP's sodium), for this site, within seven days,
  once, and within bounds: a product's price (at most to half or double), sale
  price (at most 60% off), stock status and name; or a design change (CSS that
  loads and runs nothing, text set as text, a line across the top).
* Keeps the approved design changes in this site's own database and puts them
  on the page from here.
* Keeps a log of everything that arrived: what, who signed, done or refused.

== Connecting ==
Tools > AgentFeed. Enter the one-time code from the studio. The plugin shows
the studio's signing devices with their fingerprints; compare them with the
studio's desk, tick, and approve. The site makes a key of its own for its
reports, and pins exactly those devices. A device added later is accepted only
when a pinned team device signed for it. Remove a device there at any time.

== Disconnecting ==
Tools > AgentFeed > Disconnect, or deactivate the plugin. The site's key and
the trusted devices are deleted. Approved design changes stay until removed
on the same page.

== Caching ==
WP Rocket, LiteSpeed, Autoptimize: the script tag carries data-no-optimize and
data-cfasync. Approved changes are in the page itself, so a cached page shows
them as of when it was cached: clear the cache after a change if needed.
