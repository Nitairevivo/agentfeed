=== AgentFeed Connect ===
Requires at least: 5.6
Stable tag: 1.0.0
License: GPLv2 or later

Connects the site to its studio's system: visit counts for the owner's panel,
and design changes the studio approved (CSS, text, hidden elements). No settings.

== Installation ==
1. Plugins > Add New > Upload Plugin, choose agentfeed-connect.zip, Activate.
   Many sites at once: MainWP or ManageWP can upload the same zip to every site.
2. Caching plugins (WP Rocket, LiteSpeed, Autoptimize): exclude connect.js from
   delaying and combining. The tag already carries data-no-optimize and data-cfasync.
