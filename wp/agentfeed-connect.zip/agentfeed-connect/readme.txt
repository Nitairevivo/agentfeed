=== AgentFeed Connect ===
Requires at least: 5.6
Stable tag: 1.1.0
License: GPLv2 or later

Connects the site to its studio's system: visit counts for the owner's panel,
and design changes the studio approved (CSS, text, hidden elements). No settings.

== Installation ==
1. Plugins > Add New > Upload Plugin, choose agentfeed-connect.zip, Activate.
   Many sites at once: MainWP or ManageWP can upload the same zip to every site.
2. Caching plugins (WP Rocket, LiteSpeed, Autoptimize): exclude connect.js from
   delaying and combining. The tag already carries data-no-optimize and data-cfasync.

== Direct connection (optional) ==
Tools > AgentFeed. With a one-time code from the studio, the plugin makes an
application password named "AgentFeed" for the signed-in user and sends it
once to the studio's system. Through it, and only after someone approves on
the studio's desk, Claude changes a WooCommerce product's price, sale price,
stock status or name. Disconnect there, deactivate the plugin, or revoke the
password under Users > Profile to end it. A Shop Manager user is recommended.
