<?php
/**
 * Plugin Name: AgentFeed Connect
 * Description: מחבר את האתר למערכת של הסטודיו: ספירה ללוח של בעל העסק, ושינויי עיצוב שאושרו במסך הצוות. בלי הגדרות.
 * Version: 1.1.0
 * Requires at least: 5.6
 * Author: AgentFeed
 * License: GPL-2.0-or-later
 *
 * What it does: one script tag in <head>, the same line any site can carry
 * (https://agentfeed-plum.vercel.app/connect.js). The line counts visits and
 * presses for the owner's panel, and applies design changes the studio
 * approved: CSS, new text for an element, elements to hide. It cannot run
 * code on the site or load anything else; those limits are enforced on our
 * server and again by the line itself (server/lib/patches.mjs).
 *
 * The site's id is its domain with dashes (shop.example.co.il → shop-example-co-il),
 * or what is set in Settings → General → AgentFeed.
 *
 * The direct connection (Tools → AgentFeed), only when the owner asks for it:
 * with a one-time code from the studio, the plugin makes a WordPress
 * application password named "AgentFeed" for the signed-in user and sends it
 * once to our server, which checks it and keeps it encrypted. Through it, and
 * only after someone approves on the studio's desk, Claude changes a
 * WooCommerce product's price, sale price, stock status or name
 * (server/lib/wpdirect.mjs). "Disconnect" here, deactivating the plugin, or
 * revoking the password under Users → Profile ends it at once.
 */
if (!defined('ABSPATH')) exit;

function agentfeed_connect_slug() {
	$s = (string) get_option('agentfeed_site', '');
	if ($s === '') {
		$h = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
		$h = preg_replace('/^www\./', '', $h);
		$s = preg_replace('/[^a-z0-9]+/', '-', $h);
	}
	$s = substr(trim($s, '-'), 0, 60);
	return preg_match('/^[a-z0-9-]{1,60}$/', $s) ? $s : '';
}

add_action('wp_head', function () {
	// not inside the page builder's own editor: a change on top would confuse the builder
	if (is_admin() || (function_exists('is_customize_preview') && is_customize_preview())) return;
	foreach (array('elementor-preview', 'et_fb', 'fl_builder', 'bricks', 'ct_builder', 'breakdance', 'brizy-edit-iframe', 'vc_editable') as $editor) {
		if (isset($_GET[$editor])) return;
	}
	$s = agentfeed_connect_slug();
	if ($s === '') return;
	echo '<script src="https://agentfeed-plum.vercel.app/connect.js" data-site="' . esc_attr($s) . '" async data-no-optimize="1" data-cfasync="false"></script>' . "\n";
}, 1);

add_action('admin_init', function () {
	register_setting('general', 'agentfeed_site', array(
		'type' => 'string',
		'sanitize_callback' => function ($v) {
			$v = strtolower(trim((string) $v));
			return preg_match('/^[a-z0-9-]{0,60}$/', $v) ? $v : '';
		},
	));
	add_settings_field('agentfeed_site', 'AgentFeed', function () {
		echo '<input name="agentfeed_site" value="' . esc_attr(get_option('agentfeed_site', '')) . '" class="regular-text" dir="ltr" placeholder="' . esc_attr(agentfeed_connect_slug()) . '">';
		echo '<p class="description">מזהה האתר במערכת. אם ריק, לפי שם הדומיין.</p>';
	}, 'general');
});

// ── the direct connection: Tools → AgentFeed ────────────────────────────────

const AGENTFEED_API = 'https://agentfeed-plum.vercel.app/api/panel';

function agentfeed_direct_disconnect() {
	$d = get_option('agentfeed_direct');
	if (is_array($d) && !empty($d['uuid']) && class_exists('WP_Application_Passwords')) {
		WP_Application_Passwords::delete_application_password((int) $d['user'], $d['uuid']);
	}
	delete_option('agentfeed_direct');
}
register_deactivation_hook(__FILE__, 'agentfeed_direct_disconnect');

function agentfeed_direct_connect($code) {
	$code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $code));
	if (!preg_match('/^[A-Z0-9]{8}$/', $code)) return 'הקוד לא תקין. הוא בן 8 תווים, והסטודיו מקבל אותו במסך הצוות.';
	if (agentfeed_connect_slug() === '') return 'לא הצלחתי לזהות את האתר. הגדירו מזהה בהגדרות ← כללי ← AgentFeed.';
	if (!class_exists('WP_Application_Passwords') || !function_exists('wp_is_application_passwords_available')) return 'צריך וורדפרס 5.6 ומעלה.';
	if (!wp_is_application_passwords_available()) return 'סיסמאות אפליקציה כבויות באתר הזה. ברוב המקרים זה כי האתר לא ב-https, או שתוסף אבטחה כיבה אותן.';
	$user = wp_get_current_user();
	agentfeed_direct_disconnect();   // one connection at a time
	$made = WP_Application_Passwords::create_new_application_password($user->ID, array('name' => 'AgentFeed'));
	if (is_wp_error($made)) return 'לא הצלחתי ליצור סיסמה: ' . $made->get_error_message();
	list($password, $item) = $made;
	$r = wp_remote_post(AGENTFEED_API . '?op=wp-pair', array(
		'timeout' => 25,
		'headers' => array('content-type' => 'application/json'),
		'body' => wp_json_encode(array('site' => agentfeed_connect_slug(), 'code' => $code, 'url' => home_url('/'),
		                               'user' => $user->user_login, 'password' => $password)),
	));
	if (is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200) {
		// nothing half-made is left behind: the password goes as it came
		WP_Application_Passwords::delete_application_password($user->ID, $item['uuid']);
		$body = is_wp_error($r) ? array() : json_decode(wp_remote_retrieve_body($r), true);
		return 'החיבור לא הצליח: ' . (is_array($body) && !empty($body['error']) ? $body['error'] : 'השרת לא ענה. נסו שוב בעוד דקה.');
	}
	update_option('agentfeed_direct', array('user' => $user->ID, 'uuid' => $item['uuid'], 'login' => $user->user_login, 'at' => current_time('mysql')), false);
	return '';
}

add_action('admin_menu', function () {
	add_management_page('AgentFeed', 'AgentFeed', 'manage_options', 'agentfeed-direct', 'agentfeed_direct_page');
});

function agentfeed_direct_page() {
	if (!current_user_can('manage_options')) return;
	$note = ''; $ok = false;
	if (isset($_POST['af_action']) && check_admin_referer('agentfeed_direct')) {
		if ($_POST['af_action'] === 'connect') {
			$err = agentfeed_direct_connect(sanitize_text_field(wp_unslash($_POST['af_code'] ?? '')));
			$ok = $err === ''; $note = $ok ? 'מחובר. מעכשיו הסטודיו יכול לבקש מ-Claude שינויים במוצרים, וכל שינוי ייכנס רק אחרי אישור.' : $err;
		}
		if ($_POST['af_action'] === 'disconnect') { agentfeed_direct_disconnect(); $ok = true; $note = 'החיבור נותק, והסיסמה נמחקה מהאתר.'; }
	}
	$d = get_option('agentfeed_direct');
	echo '<div class="wrap" dir="rtl"><h1>AgentFeed: חיבור ישיר</h1>';
	if ($note !== '') echo '<div class="notice ' . ($ok ? 'notice-success' : 'notice-error') . '"><p>' . esc_html($note) . '</p></div>';
	echo '<p>החיבור הישיר נותן ל-Claude לשנות במוצרי ווקומרס <b>רק</b> מחיר, מחיר מבצע, מלאי ושם. כל שינוי מוצג קודם לסטודיו, נכנס לחנות רק אחרי אישור, ואפשר לבטל אותו.</p>';
	echo '<p>טכנית זו סיסמת אפליקציה של המשתמש שמחובר עכשיו, עם ההרשאות שלו. <b>מומלץ</b> להתחבר עם משתמש בתפקיד "מנהל חנות" ולא מנהל ראשי.</p>';
	if (is_array($d)) {
		echo '<p>✅ מחובר מ-' . esc_html($d['at']) . ', דרך המשתמש <code>' . esc_html($d['login'] ?? '') . '</code>.</p>';
		echo '<form method="post">'; wp_nonce_field('agentfeed_direct');
		echo '<input type="hidden" name="af_action" value="disconnect"><p><button class="button">ניתוק</button></p></form>';
		echo '<p class="description">אפשר לנתק גם ממשתמשים ← פרופיל ← סיסמאות אפליקציה. נטרול התוסף מנתק גם הוא.</p>';
	} else {
		echo '<form method="post">'; wp_nonce_field('agentfeed_direct');
		echo '<input type="hidden" name="af_action" value="connect">';
		echo '<p><label>קוד חיבור מהסטודיו <input name="af_code" class="regular-text" dir="ltr" maxlength="12" autocomplete="off" required></label></p>';
		echo '<p><button class="button button-primary">אישור חיבור ישיר</button></p></form>';
	}
	echo '</div>';
}
