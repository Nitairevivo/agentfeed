<?php
/**
 * Plugin Name: AgentFeed Connect
 * Description: מחבר את האתר למערכת של הסטודיו: ספירה ללוח של בעל העסק, ושינויי עיצוב שאושרו במסך הצוות. בלי הגדרות.
 * Version: 1.0.0
 * Requires at least: 5.6
 * Author: AgentFeed
 * License: GPL-2.0-or-later
 *
 * What it does: one script tag in <head>, the same line any site can carry
 * (https://agentfeed-plum.vercel.app/connect.js). The line counts visits and
 * presses for the owner's panel, and applies design changes the studio
 * approved: CSS, new text for an element, elements to hide. It cannot run
 * code on the site or load anything else; those limits are enforced on our
 * server and again by the line itself (server/lib/patches.mjs).
 *
 * The site's id is its domain with dashes (shop.example.co.il → shop-example-co-il),
 * or what is set in Settings → General → AgentFeed.
 */
if (!defined('ABSPATH')) exit;

function agentfeed_connect_slug() {
	$s = (string) get_option('agentfeed_site', '');
	if ($s === '') {
		$h = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
		$h = preg_replace('/^www\./', '', $h);
		$s = preg_replace('/[^a-z0-9]+/', '-', $h);
	}
	$s = substr(trim($s, '-'), 0, 60);
	return preg_match('/^[a-z0-9-]{1,60}$/', $s) ? $s : '';
}

add_action('wp_head', function () {
	// not inside the page builder's own editor: a change on top would confuse the builder
	if (is_admin() || isset($_GET['elementor-preview']) || isset($_GET['et_fb']) || isset($_GET['fl_builder'])) return;
	$s = agentfeed_connect_slug();
	if ($s === '') return;
	echo '<script src="https://agentfeed-plum.vercel.app/connect.js" data-site="' . esc_attr($s) . '" async data-no-optimize="1" data-cfasync="false"></script>' . "\n";
}, 1);

add_action('admin_init', function () {
	register_setting('general', 'agentfeed_site', array(
		'type' => 'string',
		'sanitize_callback' => function ($v) {
			$v = strtolower(trim((string) $v));
			return preg_match('/^[a-z0-9-]{0,60}$/', $v) ? $v : '';
		},
	));
	add_settings_field('agentfeed_site', 'AgentFeed', function () {
		echo '<input name="agentfeed_site" value="' . esc_attr(get_option('agentfeed_site', '')) . '" class="regular-text" dir="ltr" placeholder="' . esc_attr(agentfeed_connect_slug()) . '">';
		echo '<p class="description">מזהה האתר במערכת. אם ריק, לפי שם הדומיין.</p>';
	}, 'general');
});
