<?php
/**
 * Plugin Name: AgentFeed Connect
 * Description: מחבר את האתר למערכת של הסטודיו: מדידה בלי עוגיות, ושינויים שהסטודיו אישר וחתם עליהם. אין לנו סיסמה לאתר.
 * Version: 2.1.0
 * Requires at least: 5.6
 * Requires PHP: 7.4
 * Author: AgentFeed
 * License: GPLv2 or later
 *
 * What this plugin will do, and nothing else:
 *   - count visits and presses (WhatsApp, call, cart) with a script that ships inside this plugin:
 *     no cookie, nothing kept on the visitor's device, nothing loaded from anywhere else;
 *   - carry out a change only when one of the studio's devices signed it, and only within bounds:
 *     a product's price (to at most half or double), sale price (at most 60% off), stock and name,
 *     or a design patch (CSS that loads and runs nothing, text set as text, a line across the top).
 *
 * It holds no password of ours and gives us none of yours. The AgentFeed server carries signed
 * messages from the studio's browser to here; this plugin checks each one itself (includes/core.php).
 * If that server were taken over, the most it could do is stop delivering.
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/includes/core.php';

if (!defined('AGENTFEED_API')) define('AGENTFEED_API', 'https://agentfeed-plum.vercel.app');   // a test points it elsewhere
const AGENTFEED_VERSION = '2.1.0';

// ── which site this is ──────────────────────────────────────────────────────

function agentfeed_connect_slug() {
	$c = get_option('agentfeed_conn');
	if (is_array($c) && !empty($c['site'])) return $c['site'];
	$s = (string) get_option('agentfeed_site', '');
	if ($s === '') {
		$h = strtolower((string) wp_parse_url(home_url(), PHP_URL_HOST));
		$h = preg_replace('/^www\./', '', $h);
		$s = preg_replace('/[^a-z0-9]+/', '-', $h);
	}
	$s = substr(trim($s, '-'), 0, 60);
	return preg_match('/^[a-z0-9-]{1,60}$/', $s) ? $s : '';
}
function agentfeed_connected() { $c = get_option('agentfeed_conn'); return is_array($c) && !empty($c['agency']) ? $c : null; }

add_action('admin_init', function () {
	register_setting('general', 'agentfeed_site', array(
		'type' => 'string',
		'sanitize_callback' => function ($v) {
			$v = strtolower(trim((string) $v));
			return preg_match('/^[a-z0-9-]{0,60}$/', $v) ? $v : '';
		},
	));
	add_settings_field('agentfeed_site', 'AgentFeed', function () {
		echo '<input name="agentfeed_site" value="' . esc_attr(get_option('agentfeed_site', '')) . '" class="regular-text" dir="ltr" placeholder="' . esc_attr(agentfeed_connect_slug()) . '">';
		echo '<p class="description">מזהה האתר במערכת. אם ריק, לפי שם הדומיין.</p>';
	}, 'general');
	// the "write to us" window: off until someone who runs the site turns it on here (and the inbox is on at the studio)
	register_setting('general', 'agentfeed_inbox', array('type' => 'string', 'sanitize_callback' => function ($v) { return $v === '1' ? '1' : ''; }));
	add_settings_field('agentfeed_inbox', 'AgentFeed — חלון פניות', function () {
		echo '<label><input type="checkbox" name="agentfeed_inbox" value="1"' . (get_option('agentfeed_inbox', '') === '1' ? ' checked' : '') . '> להציג באתר חלון "כתבו לנו"</label>';
		echo '<p class="description">התשובות רק ממה שכתוב באתר. מה שלא כתוב בו עובר לבעל העסק.</p>';
	}, 'general');
});

// ── the page: approved patches from this site's own database, and the counting script from this plugin ──

function agentfeed_in_editor() {
	if (is_admin() || (function_exists('is_customize_preview') && is_customize_preview())) return true;
	foreach (array('elementor-preview', 'et_fb', 'fl_builder', 'bricks', 'ct_builder', 'breakdance', 'brizy-edit-iframe', 'vc_editable') as $editor) {
		if (isset($_GET[$editor])) return true;
	}
	return false;
}

add_action('wp_head', function () {
	// not inside the page builder's own editor: a change on top would confuse the builder
	if (agentfeed_in_editor()) return;
	$s = agentfeed_connect_slug();
	if ($s === '') return;
	$page = agentfeed_page_patch(array_values((array) get_option('agentfeed_patches', array())));
	if ($page['css'] !== '') echo '<style id="af-patch">' . $page['css'] . "\n</style>\n";   // no "<" can be in it: cleaned twice
	$data = array('text' => $page['text'], 'bar' => $page['bar']);
	echo '<script type="application/json" id="af-data">' . wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) . "</script>\n";
	// a preview of a change not yet approved, and a drawn page for the studio, only for someone logged in who
	// edits this site: a link with a preview id does nothing for anyone else
	$editor = is_user_logged_in() && current_user_can('edit_posts') ? '1' : '';
	echo '<script src="' . esc_url(plugins_url('assets/agentfeed.js', __FILE__) . '?v=' . AGENTFEED_VERSION) . '" data-site="' . esc_attr($s) .
	     '" data-api="' . esc_attr(AGENTFEED_API) . '" data-editor="' . $editor . '" async data-no-optimize="1" data-cfasync="false"></script>' . "\n";
	// the "write to us" window, from this plugin's own files, only where the site turned it on
	if (get_option('agentfeed_inbox', '') === '1') {
		echo '<script src="' . esc_url(plugins_url('assets/inbox.js', __FILE__) . '?v=' . AGENTFEED_VERSION) . '" data-site="' . esc_attr($s) .
		     '" data-api="' . esc_attr(AGENTFEED_API) . '" defer data-no-optimize="1" data-cfasync="false"></script>' . "\n";
	}
}, 1);

// ── the door: what our server may ask of this site ──────────────────────────

add_action('rest_api_init', function () {
	// a knock: "there is something new for you". It carries nothing; the site fetches and judges by itself
	register_rest_route('agentfeed/v1', '/sync', array('methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => function () {
		if (!agentfeed_connected()) return new WP_REST_Response(array('ok' => false), 404);
		if (get_transient('agentfeed_knock')) return array('ok' => true, 'later' => true);
		set_transient('agentfeed_knock', 1, 10);
		agentfeed_pull();
		return array('ok' => true);
	}));
	// the products as any visitor sees them: published, with their public price and stock. Nothing else
	register_rest_route('agentfeed/v1', '/products', array('methods' => 'GET', 'permission_callback' => '__return_true', 'callback' => function (WP_REST_Request $r) {
		if (!agentfeed_connected() || !function_exists('wc_get_products')) return new WP_REST_Response(array('list' => array()), 404);
		$args = array('status' => 'publish', 'limit' => 500, 'visibility' => 'visible');
		$q = sanitize_text_field((string) $r->get_param('search'));
		if ($q !== '') $args['s'] = mb_substr($q, 0, 60);
		$list = array();
		foreach (wc_get_products($args) as $p) {
			$list[] = array('id' => $p->get_id(), 'name' => $p->get_name(), 'sku' => $p->get_sku(), 'regular_price' => $p->is_type('simple') ? (string) $p->get_regular_price() : '',
			                'sale_price' => $p->is_type('simple') ? (string) $p->get_sale_price() : '', 'stock_status' => $p->get_stock_status());
		}
		return array('list' => $list);
	}));
});

add_filter('cron_schedules', function ($s) { $s['agentfeed_5min'] = array('interval' => 300, 'display' => 'AgentFeed, every 5 minutes'); return $s; });
add_action('agentfeed_pull', 'agentfeed_pull');
register_deactivation_hook(__FILE__, function () { wp_clear_scheduled_hook('agentfeed_pull'); });

/** Sign with this site's own key: its reports, and its requests for what is new. */
function agentfeed_site_sign($msg) {
	$sk = agentfeed_b64u_dec((string) get_option('agentfeed_sk', ''));
	return strlen($sk) === 64 ? agentfeed_b64u_enc(sodium_crypto_sign_detached($msg, $sk)) : '';
}

function agentfeed_log($entry) {
	$log = (array) get_option('agentfeed_log', array());
	array_unshift($log, $entry + array('at' => current_time('mysql')));
	update_option('agentfeed_log', array_slice($log, 0, 200), false);
}

/** Fetch what is new, judge each item, do what passes, report back. Safe to run twice: an order runs once. */
function agentfeed_pull() {
	$c = agentfeed_connected();
	if (!$c || get_transient('agentfeed_pulling')) return;
	set_transient('agentfeed_pulling', 1, 60);
	$site = $c['site']; $ts = time();
	$r = wp_remote_get(AGENTFEED_API . '/api/panel?' . http_build_query(array('op' => 'signed', 'site' => $site, 'after' => (int) get_option('agentfeed_after', 0),
	                   'ts' => $ts, 'sig' => agentfeed_site_sign("AF-PULL-1\n$site\n$ts"))), array('timeout' => 15));
	$d = is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200 ? null : json_decode(wp_remote_retrieve_body($r), true);
	if (!is_array($d) || ($d['agency'] ?? '') !== $c['agency']) { delete_transient('agentfeed_pulling'); return; }

	// the devices first: new ones only through a trusted device's signature, removed ones for good
	$tr = (array) get_option('agentfeed_trust', array('keys' => array(), 'gone' => array()));
	list($keys, $gone) = agentfeed_trust_walk($c['agency'], (array) ($tr['keys'] ?? array()), (array) ($d['keys'] ?? array()), (array) ($d['revokes'] ?? array()), (array) ($tr['gone'] ?? array()));
	update_option('agentfeed_trust', array('keys' => $keys, 'gone' => $gone), false);

	$seen = (array) get_option('agentfeed_seen', array());
	foreach ($seen as $id => $t) if ($t < time() - 9 * 86400) unset($seen[$id]);
	$results = array(); $after = (int) get_option('agentfeed_after', 0);
	foreach (array_slice((array) ($d['items'] ?? array()), 0, 50) as $item) {
		$after = max($after, (int) ($item['seq'] ?? 0));
		if (($item['type'] ?? '') !== 'order') continue;
		$j = agentfeed_check_order($item, array('agency' => $c['agency'], 'site' => $site, 'trusted' => $keys, 'seen' => $seen, 'now' => time()));
		if (!empty($j['seen'])) continue;
		$o = $j['order'] ?? null;
		$m = $o ?: json_decode((string) ($item['msg'] ?? ''), true);
		$id = is_array($m) && preg_match('/^[a-f0-9]{24}$/', (string) ($m['id'] ?? '')) ? $m['id'] : '';
		if (!$o) {
			// refused: said so in the log and to the studio, and never marked done, so a forged copy cannot block the real one
			agentfeed_log(array('id' => $id, 'kind' => '', 'ok' => false, 'why' => $j['error'], 'by' => ''));
			if ($id !== '') $results[] = array('id' => $id, 'ok' => false, 'why' => $j['error']);
			continue;
		}
		$seen[$id] = time();
		$done = agentfeed_carry_out($o, $j['key']);
		agentfeed_log(array('id' => $id, 'kind' => $o['kind'], 'ok' => $done['ok'], 'why' => $done['why'] ?? '', 'by' => $j['key']['name'], 'fp' => agentfeed_fingerprint($j['key']['kid']), 'what' => $done['what'] ?? ''));
		$results[] = array('id' => $id, 'ok' => $done['ok'], 'failed' => $done['failed'] ?? array(), 'why' => $done['why'] ?? '');
	}
	update_option('agentfeed_seen', $seen, false);
	update_option('agentfeed_after', $after, false);
	if ($results) {
		$msg = wp_json_encode(array('site' => $site, 'results' => $results, 'at' => time()));
		wp_remote_post(AGENTFEED_API . '/api/panel?op=signed-ack&site=' . rawurlencode($site), array('timeout' => 15, 'headers' => array('content-type' => 'application/json'),
		               'body' => wp_json_encode(array('site' => $site, 'msg' => $msg, 'sig' => agentfeed_site_sign($msg)))));
	}
	delete_transient('agentfeed_pulling');
}

/** One order that passed: done here, with what it replaced kept here, so an undo restores this site's own values. */
function agentfeed_carry_out(array $o, array $key) {
	$undo = (array) get_option('agentfeed_undo', array());
	$id = $o['id'];
	if ($o['kind'] === 'patch') {
		if (isset($undo["x$id"])) return array('ok' => false, 'why' => 'cancelled before it arrived');
		$p = agentfeed_clean_patch($o['body']);
		if (!$p) return array('ok' => false, 'why' => 'the patch is outside what a design change may hold');
		$all = (array) get_option('agentfeed_patches', array());
		$all[$id] = $p + array('by' => $key['name'], 'at' => current_time('mysql'));
		update_option('agentfeed_patches', array_slice($all, -50, null, true));
		return array('ok' => true, 'what' => 'שינוי עיצוב');
	}
	if ($o['kind'] === 'patch-undo' || $o['kind'] === 'wp-undo') {
		$of = (string) ($o['body']['of'] ?? '');
		if (!preg_match('/^[a-f0-9]{24}$/', $of)) return array('ok' => false, 'why' => 'not an undo');
		if ($o['kind'] === 'patch-undo') {
			$all = (array) get_option('agentfeed_patches', array());
			if (!isset($all[$of])) { $undo["x$of"] = time(); update_option('agentfeed_undo', $undo, false); return array('ok' => true, 'what' => 'ביטול (השינוי לא היה באתר)'); }
			unset($all[$of]); update_option('agentfeed_patches', $all);
			return array('ok' => true, 'what' => 'ביטול שינוי עיצוב');
		}
		$was = $undo[$of] ?? null;
		if (!is_array($was)) { $undo["x$of"] = time(); update_option('agentfeed_undo', $undo, false); return array('ok' => true, 'what' => 'ביטול (השינוי לא היה באתר)'); }
		$failed = array();
		foreach ($was as $ch) {
			$p = function_exists('wc_get_product') ? wc_get_product($ch['id']) : null;
			// only where the value is still the one we set: a change made by hand since is the shop's, and stays
			if (!$p || (string) agentfeed_get($p, $ch['field']) !== (string) $ch['after']) { $failed[] = (int) $ch['id']; continue; }
			agentfeed_set($p, $ch['field'], $ch['before']); $p->save();
		}
		unset($undo[$of]); update_option('agentfeed_undo', $undo, false);
		return array('ok' => true, 'failed' => array_values(array_unique($failed)), 'what' => 'ביטול שינוי במוצרים');
	}
	// 'wp': products, judged against the store as it is now
	if (isset($undo["x$id"])) return array('ok' => false, 'why' => 'cancelled before it arrived');
	if (!function_exists('wc_get_product')) return array('ok' => false, 'why' => 'no WooCommerce on this site');
	$current = array();
	foreach (array_slice((array) ($o['body']['changes'] ?? array()), 0, 30) as $c) {
		$p = wc_get_product((int) ($c['id'] ?? 0));
		if ($p && $p->get_status() === 'publish') $current[$p->get_id()] = array('regular_price' => (string) $p->get_regular_price(), 'sale_price' => (string) $p->get_sale_price(),
		                                               'stock_status' => $p->get_stock_status(), 'name' => $p->get_name(), 'simple' => $p->is_type('simple'));
	}
	$ok = agentfeed_clean_changes($o['body']['changes'] ?? array(), $current);
	$asked = count((array) ($o['body']['changes'] ?? array()));
	$record = array(); $failed = array();
	foreach ($ok as $ch) {
		$p = wc_get_product($ch['id']);
		$before = (string) agentfeed_get($p, $ch['field']);
		agentfeed_set($p, $ch['field'], $ch['value']);
		if ($p->save()) $record[] = array('id' => $ch['id'], 'field' => $ch['field'], 'before' => $before, 'after' => $ch['value']);
		else $failed[] = $ch['id'];
	}
	$passed = array_map(function ($x) { return $x['id']; }, $ok);
	foreach ((array) ($o['body']['changes'] ?? array()) as $c) if (!in_array((int) ($c['id'] ?? 0), $passed, true)) $failed[] = (int) ($c['id'] ?? 0);
	$undo[$id] = $record; update_option('agentfeed_undo', array_slice($undo, -200, null, true), false);
	return array('ok' => (bool) $record || !$asked, 'failed' => array_values(array_unique($failed)), 'why' => $record ? '' : 'no change passed the bounds', 'what' => count($record) . ' שינויים במוצרים');
}
function agentfeed_get($p, $field) {
	switch ($field) { case 'regular_price': return $p->get_regular_price(); case 'sale_price': return $p->get_sale_price(); case 'stock_status': return $p->get_stock_status(); case 'name': return $p->get_name(); }
	return '';
}
function agentfeed_set($p, $field, $v) {
	switch ($field) { case 'regular_price': $p->set_regular_price($v); break; case 'sale_price': $p->set_sale_price($v); break;
	                  case 'stock_status': $p->set_stock_status($v); break; case 'name': $p->set_name(sanitize_text_field($v)); break; }
}

// ── connecting: Tools → AgentFeed ───────────────────────────────────────────

function agentfeed_admin_cap() { return class_exists('WooCommerce') ? 'manage_woocommerce' : 'manage_options'; }
add_action('admin_menu', function () { add_management_page('AgentFeed', 'AgentFeed', agentfeed_admin_cap(), 'agentfeed-direct', 'agentfeed_direct_page'); });

/** Step one: the code says which studio. Its devices are shown to the owner, and kept for step two. */
function agentfeed_fetch_trust($code) {
	$code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) $code));
	if (!preg_match('/^[A-Z0-9]{8}$/', $code)) return 'הקוד לא תקין. הוא בן 8 תווים, והסטודיו מקבל אותו במסך הצוות.';
	if (!function_exists('sodium_crypto_sign_verify_detached')) return 'חסרה באתר ספריית ההצפנה של PHP (sodium). פנו לחברת האחסון.';
	$r = wp_remote_get(AGENTFEED_API . '/api/panel?op=wp-trust&code=' . rawurlencode($code), array('timeout' => 15));
	$d = is_wp_error($r) ? null : json_decode(wp_remote_retrieve_body($r), true);
	if (!is_array($d) || wp_remote_retrieve_response_code($r) !== 200) return 'החיבור לא הצליח: ' . (is_array($d) && !empty($d['error']) ? $d['error'] : 'השרת לא ענה. נסו שוב בעוד דקה.');
	list($keys) = agentfeed_first_trust((string) $d['agency'], (array) ($d['keys'] ?? array()), (array) ($d['revokes'] ?? array()));
	if (!$keys) return 'לא התקבל אף מכשיר חתימה תקין של הסטודיו.';
	set_transient('agentfeed_offer_' . get_current_user_id(), array('code' => $code, 'agency' => (string) $d['agency'], 'name' => mb_substr((string) ($d['name'] ?? ''), 0, 80), 'site' => (string) ($d['site'] ?? ''), 'keys' => $keys), 900);
	return '';
}

/** Step two: the owner saw the devices and approved. The site makes its own key, and pins exactly those devices. */
function agentfeed_confirm() {
	$offer = get_transient('agentfeed_offer_' . get_current_user_id());
	if (!is_array($offer)) return 'עבר יותר מדי זמן. הזינו את הקוד שוב.';
	if (!preg_match('/^[a-z0-9-]{1,60}$/', $offer['site'])) return 'מזהה האתר לא תקין.';
	$pair = sodium_crypto_sign_keypair();
	$pub = agentfeed_b64u_enc(sodium_crypto_sign_publickey($pair));
	$r = wp_remote_post(AGENTFEED_API . '/api/panel?op=wp-pair', array('timeout' => 20, 'headers' => array('content-type' => 'application/json'),
		'body' => wp_json_encode(array('code' => $offer['code'], 'url' => home_url('/'), 'rest' => rest_url(), 'sitePub' => $pub, 'woo' => class_exists('WooCommerce')))));
	$d = is_wp_error($r) ? null : json_decode(wp_remote_retrieve_body($r), true);
	if (wp_remote_retrieve_response_code($r) !== 200 || empty($d['ok']) || ($d['agency'] ?? '') !== $offer['agency']) return 'החיבור לא הצליח: ' . (is_array($d) && !empty($d['error']) ? $d['error'] : 'השרת לא ענה.');
	update_option('agentfeed_sk', agentfeed_b64u_enc(sodium_crypto_sign_secretkey($pair)), false);
	update_option('agentfeed_trust', array('keys' => $offer['keys'], 'gone' => array()), false);
	update_option('agentfeed_conn', array('agency' => $offer['agency'], 'name' => $offer['name'], 'site' => $offer['site'], 'at' => current_time('mysql'),
	              'by' => wp_get_current_user()->user_login, 'sitekid' => agentfeed_kid($pub)), false);
	update_option('agentfeed_after', 0, false);
	delete_transient('agentfeed_offer_' . get_current_user_id());
	if (!wp_next_scheduled('agentfeed_pull')) wp_schedule_event(time() + 60, 'agentfeed_5min', 'agentfeed_pull');
	agentfeed_log(array('id' => '', 'kind' => 'connect', 'ok' => true, 'why' => '', 'by' => wp_get_current_user()->user_login, 'what' => 'חיבור לסטודיו ' . $offer['name']));
	return '';
}

function agentfeed_disconnect() {
	foreach (array('agentfeed_conn', 'agentfeed_sk', 'agentfeed_trust', 'agentfeed_after', 'agentfeed_seen') as $o) delete_option($o);
	wp_clear_scheduled_hook('agentfeed_pull');
	agentfeed_log(array('id' => '', 'kind' => 'disconnect', 'ok' => true, 'why' => '', 'by' => wp_get_current_user()->user_login, 'what' => 'ניתוק'));
}

function agentfeed_scope_he($scope) {
	if ($scope === 'team') return 'צוות הסטודיו';
	if (preg_match('/^client:[a-z0-9-]+:(design|store|both|all)$/', $scope, $m)) return 'בעל האתר · ' . array('design' => 'עיצוב', 'store' => 'מוצרים', 'both' => 'עיצוב ומוצרים', 'all' => 'הכול')[$m[1]];
	return $scope;
}
function agentfeed_devices_table($keys, $remove = false) {
	echo '<table class="widefat striped" style="max-width:820px"><thead><tr><th>מכשיר</th><th>טביעת אצבע</th><th>מורשה ל</th>' . ($remove ? '<th></th>' : '') . '</tr></thead><tbody>';
	foreach ($keys as $k) {
		echo '<tr><td>' . esc_html($k['name']) . '</td><td dir="ltr"><code>' . esc_html(agentfeed_fingerprint($k['kid'])) . '</code></td><td>' . esc_html(agentfeed_scope_he($k['scope'])) . '</td>';
		if ($remove) { echo '<td><form method="post" style="margin:0">'; wp_nonce_field('agentfeed_direct'); echo '<input type="hidden" name="af_action" value="drop"><input type="hidden" name="af_kid" value="' . esc_attr($k['kid']) . '"><button class="button-link-delete" onclick="return confirm(\'להסיר את המכשיר? הוא לא יוכל לחתום על שינויים באתר הזה.\')">הסרה</button></form></td>'; }
		echo '</tr>';
	}
	echo '</tbody></table>';
}

function agentfeed_direct_page() {
	if (!current_user_can(agentfeed_admin_cap())) return;
	$note = ''; $ok = false;
	if (isset($_POST['af_action']) && check_admin_referer('agentfeed_direct')) {
		$a = $_POST['af_action'];
		if ($a === 'code') { $note = agentfeed_fetch_trust(sanitize_text_field(wp_unslash($_POST['af_code'] ?? ''))); $ok = $note === ''; }
		if ($a === 'confirm') { $note = empty($_POST['af_checked']) ? 'סמנו שהשוויתם את טביעות האצבע עם הסטודיו.' : agentfeed_confirm(); $ok = $note === ''; if ($ok) $note = 'מחובר. מעכשיו האתר יבצע רק שינויים שהמכשירים האלה חתמו עליהם.'; }
		if ($a === 'cancel') { delete_transient('agentfeed_offer_' . get_current_user_id()); }
		if ($a === 'disconnect') { agentfeed_disconnect(); $ok = true; $note = 'החיבור נותק. מפתח האתר והמכשירים המורשים נמחקו. שינויי העיצוב שאושרו נשארים באתר, ואפשר להסיר אותם למטה.'; }
		if ($a === 'sync') { delete_transient('agentfeed_pulling'); agentfeed_pull(); $ok = true; $note = 'נבדק.'; }
		if ($a === 'drop') {
			$tr = (array) get_option('agentfeed_trust', array()); $kid = sanitize_key($_POST['af_kid'] ?? '');
			unset($tr['keys'][$kid]); $tr['gone'][] = $kid; update_option('agentfeed_trust', $tr, false);
			agentfeed_log(array('id' => '', 'kind' => 'drop', 'ok' => true, 'why' => '', 'by' => wp_get_current_user()->user_login, 'what' => 'הוסר מכשיר ' . agentfeed_fingerprint($kid)));
			$ok = true; $note = 'המכשיר הוסר מהאתר הזה.';
		}
		if ($a === 'unpatch') {
			$all = (array) get_option('agentfeed_patches', array()); $pid = preg_replace('/[^a-f0-9]/', '', (string) ($_POST['af_pid'] ?? ''));
			unset($all[$pid]); update_option('agentfeed_patches', $all);
			agentfeed_log(array('id' => $pid, 'kind' => 'unpatch', 'ok' => true, 'why' => '', 'by' => wp_get_current_user()->user_login, 'what' => 'הוסר שינוי עיצוב ידנית'));
			$ok = true; $note = 'שינוי העיצוב הוסר.';
		}
	}
	$c = agentfeed_connected(); $offer = get_transient('agentfeed_offer_' . get_current_user_id());
	echo '<div class="wrap" dir="rtl"><h1>AgentFeed</h1>';
	if ($note !== '') echo '<div class="notice ' . ($ok ? 'notice-success' : 'notice-error') . '"><p>' . esc_html($note) . '</p></div>';
	echo '<p>התוסף מבצע באתר רק שינוי שאחד המכשירים המורשים של הסטודיו <b>חתם עליו דיגיטלית</b>: מחיר (עד חצי או כפול), מחיר מבצע (עד 60% הנחה), מלאי ושם של מוצר, או שינוי עיצוב שלא טוען ולא מריץ שום קוד. ';
	echo 'אין ל-AgentFeed סיסמה לאתר הזה, ושינוי בלי חתימה תקפה נזרק.</p>';
	if ($c) {
		$tr = (array) get_option('agentfeed_trust', array());
		echo '<h2>מחובר לסטודיו ' . esc_html($c['name']) . '</h2><p>מאז ' . esc_html($c['at']) . ', דרך ' . esc_html($c['by']) . '. מפתח האתר: <code dir="ltr">' . esc_html(agentfeed_fingerprint($c['sitekid'])) . '</code></p>';
		echo '<h3>מכשירים שמורשים לחתום</h3>'; agentfeed_devices_table((array) ($tr['keys'] ?? array()), true);
		echo '<form method="post" style="margin-top:12px;display:inline-block">'; wp_nonce_field('agentfeed_direct'); echo '<input type="hidden" name="af_action" value="sync"><button class="button">לבדוק עכשיו אם יש שינויים</button></form> ';
		echo '<form method="post" style="display:inline-block">'; wp_nonce_field('agentfeed_direct'); echo '<input type="hidden" name="af_action" value="disconnect"><button class="button" onclick="return confirm(\'לנתק? האתר יפסיק לקבל שינויים מהסטודיו.\')">ניתוק</button></form>';
	} elseif (is_array($offer)) {
		echo '<h2>אישור החיבור לסטודיו ' . esc_html($offer['name']) . '</h2>';
		echo '<p>אלה המכשירים שיוכלו לחתום על שינויים באתר. <b>השוו את טביעות האצבע</b> עם מה שמופיע אצל הסטודיו במסך הצוות (בטלפון או בשיחה). אם משהו לא תואם, אל תאשרו.</p>';
		agentfeed_devices_table($offer['keys']);
		echo '<form method="post" style="margin-top:12px">'; wp_nonce_field('agentfeed_direct');
		echo '<input type="hidden" name="af_action" value="confirm"><p><label><input type="checkbox" name="af_checked" value="1"> השוויתי את טביעות האצבע והן תואמות</label></p><p><button class="button button-primary">אישור החיבור</button></p></form>';
		echo '<form method="post">'; wp_nonce_field('agentfeed_direct'); echo '<input type="hidden" name="af_action" value="cancel"><button class="button-link">ביטול</button></form>';
	} else {
		echo '<form method="post">'; wp_nonce_field('agentfeed_direct');
		echo '<input type="hidden" name="af_action" value="code"><p><label>קוד חיבור מהסטודיו <input name="af_code" class="regular-text" dir="ltr" maxlength="12" autocomplete="off" required></label></p>';
		echo '<p><button class="button button-primary">המשך</button></p></form>';
	}
	$patches = (array) get_option('agentfeed_patches', array());
	if ($patches) {
		echo '<h3>שינויי עיצוב שפעילים באתר</h3><table class="widefat striped" style="max-width:820px"><tbody>';
		foreach ($patches as $pid => $p) {
			$what = array(); if (!empty($p['css'])) $what[] = 'עיצוב'; if (!empty($p['text'])) $what[] = count($p['text']) . ' טקסטים'; if (!empty($p['hide'])) $what[] = count($p['hide']) . ' הסתרות'; if (!empty($p['bar'])) $what[] = 'פס עליון';
			echo '<tr><td>' . esc_html($p['at'] ?? '') . '</td><td>' . esc_html(implode(', ', $what)) . '</td><td>חתם: ' . esc_html($p['by'] ?? '') . '</td><td><form method="post" style="margin:0">'; wp_nonce_field('agentfeed_direct');
			echo '<input type="hidden" name="af_action" value="unpatch"><input type="hidden" name="af_pid" value="' . esc_attr($pid) . '"><button class="button-link-delete">הסרה</button></form></td></tr>';
		}
		echo '</tbody></table>';
	}
	$log = array_slice((array) get_option('agentfeed_log', array()), 0, 50);
	if ($log) {
		echo '<h3>יומן</h3><p class="description">כל מה שהגיע לאתר, מי חתם, ומה נעשה. גם מה שנזרק.</p><table class="widefat striped" style="max-width:820px"><thead><tr><th>מתי</th><th>מה</th><th>חתם</th><th>תוצאה</th></tr></thead><tbody>';
		foreach ($log as $e) {
			echo '<tr><td>' . esc_html($e['at'] ?? '') . '</td><td>' . esc_html($e['what'] ?? $e['kind'] ?? '') . '</td><td>' . esc_html(trim(($e['by'] ?? '') . ' ' . ($e['fp'] ?? ''))) . '</td><td>' . ($e['ok'] ? '✅' : '⛔ ' . esc_html($e['why'] ?? '')) . '</td></tr>';
		}
		echo '</tbody></table>';
	}
	echo '</div>';
}
